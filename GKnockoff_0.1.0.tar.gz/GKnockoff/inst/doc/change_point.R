## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(GKnockoff)

## -----------------------------------------------------------------------------
set.seed(1234)
p <- 100
changepos <- sort(sample(1:p, 5))
changepos

## ---- out.width="50%"---------------------------------------------------------
amplitude <- 1 # the value of beta

changepos_ex <- c(0, changepos, p)
  Beta0 <- matrix(nrow = p)
  for(i in 1:(length(changepos_ex) - 1)){
    start <- changepos_ex[i] + 1
    end <- changepos_ex[i+1]
    Beta0[start:end, ] <- amplitude
    amplitude <- -amplitude
  }

plot(Beta0)

## -----------------------------------------------------------------------------
y <- diag(p) %*% Beta0 + rnorm(p, sd = 1)

## ---- warning= FALSE----------------------------------------------------------
FDR.fun <- function(selection, genuine){
  num_s <- length(selection)
  
  if(num_s == 0){
    fdr <- 0
  }else{
    fdr <- 1 - sum(selection %in% genuine) / num_s
  }
  return(fdr)
}

Power.fun <- function(selection, genuine){
  return(mean(genuine %in% selection))
}

fdr <- 0.3
fdr_c <- NULL
power_c <- NULL
for(i in 1:10){
  knockoff <- GKnockoff1d(y, fdr = fdr)
  fdr_c[i] <- FDR.fun(knockoff$selected, changepos)
  power_c[i] <- Power.fun(knockoff$selected, changepos)
}

mean(fdr_c)
mean(power_c)

