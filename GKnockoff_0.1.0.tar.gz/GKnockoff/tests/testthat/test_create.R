test_that('create.tilde_D works right',{
  X1 <- matrix(c(1,0,0, 1,0,0), nrow = 2, ncol = 3, byrow = T)
  X2 <- matrix(c(1,0,0, 1,0,0), nrow = 2, ncol = 3, byrow = T)

  expect_equal(create.tilde_D(D), diag(3))
})

test_that('create.dmatrix works right',{
  p = 3
  E <- matrix(0, nrow = p-1, ncol = p)
  for(i in 1:(p-1)){
    E[i,i] <- -1
    E[i, i+1] <- 1
  }

  D <- create.dmatrix(p)
  m <- dim(D)[1]
  p <- dim(D)[2]
  expect_equal(m, p-1)
  expect_equal(create.dmatrix(p), E)
})

test_that('create.gdmatrix',{
  E <- matrix(c(1,0,-1,0,0,1,0,-1), ncol = 4, byrow = T)
  expect_equal(create.gdmatrix(2,2), E)
})
