test_that('genKnockoff',{
  expect_error(genKnockoff('abs'))
})
