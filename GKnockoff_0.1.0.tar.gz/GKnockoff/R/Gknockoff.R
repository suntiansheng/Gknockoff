#' @import knockoff
NULL


#' A Generalized Knockoff Procedure for FDR Control in Structural Change Detection
#'
#' This function runs the GKnockoff procedure from start to finish, selecting structural change
#' relevant for predicting the outcome of interest.
#'
#' @param X n-by-p matrix of predictors.
#' @param y response vector of length n-by-1 matrix.
#' @param D m-by-p penalty matrix
#' @param knockoffs method used to construct knockoffs for the X variables. By defaut, create.fixed is used.
#' also see \code{\link[knockoff]{knockoff.filter}} in knockoff package
#' @param statistic used to assess variable importance. By default,
#' a lasso statistic with coefficent difference is used.
#' also see \code{\link[knockoff]{knockoff.filter}} in knockoff package
#' @param fdr target false discovery rate (default: 0.2).
#'
#' @return An object of class "Gknockoff.result". This object is a list
#'  containing at least the following components:
#'  \item{statistic}{computed test statistics}
#'  \item{threshold}{computed selection threshold}
#'  \item{selected}{named vector of selected variables}
#'
#' @details
#' The parameter \code{GKnockoff} controls how knockoff variables are created.
#' By default, if the number of samples n > 2m (m is the row number of penalty matrx \eqn{D}, that is, the number of constrains),
#'  the fixed-X scenario is assumed. if 2m < n < m,
#' the model-X scenario is assumed and a multivariate normal distribution is fitted to
#' the original variables \eqn{X}. The estimated mean vector and the covariance
#' matrix are used to generate second-order approximate Gaussian knockoffs.
#'
#' \eqn{D} is a self-specified penalty matrix for Generalized Lasso.
#'
#' The default importance statistic is \link[knockoff]{stat.lasso_coefdiff} in knockoff package,
#' other statistic in knockoff package is also fine.
#'
#' @export
GKnockoff <- function(X, y, D, knockoffs = create.fixed, statistic = stat.lasso_coefdiff, fdr = 0.2){
  y <- matrix(y, ncol = 1)
  n <- dim(X)[1]
  m <- dim(D)[1]
  p <- dim(D)[2]

  if(qr(D)$rank != m){
    stop('rank(D) < m, D is infeasible')
  }

  if(!(is.matrix(X)&is.matrix(y)&is.matrix(D))){
    stop('X or D is not a matrix')
  }
  if (!is.function(knockoffs)) stop('Input knockoffs must be a function')
  if (!is.function(statistic)) stop('Input statistic must be a function')


  if(dim(X)[2] != dim(D)[2]){stop('the columns of X is different from the columns of D')}


  #D_tilde <- Augment_D(D)
  ## append by matrix in null space
  E <- pracma::nullspace(D)
  D_tilde <- rbind(D, t(E))

  D_tilde_inverse <- solve(D_tilde)
  Z <- D_tilde_inverse[,1:m]
  F1 <- D_tilde_inverse[,(m+1):p]

  XF <- X %*% F1
  M_XF <- diag(n) - XF %*% solve(t(XF) %*% XF) %*% t(XF)
  y_bar <- M_XF %*% y
  X_bar <- M_XF %*% X %*% Z

  fit <- knockoff.filter(X_bar, y_bar, knockoffs = knockoffs,
                                   statistic = statistic, fdr = fdr, offset = 1)
  structure(list(call = match.call(),
                 statistic = fit$W,
                 threshold = fit$t,
                 selected = fit$selected),
            class = 'Gknockoff.result')
}

