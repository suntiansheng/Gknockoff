#' @import magic
NULL

#' FDR control for integration analysis via GKnockoff
#'
#' This function runs the GKnockoff procedure from start to finish for integration analysis
#'
#' @param X_list list, each element is a n_k-by-p matrix.
#' @param y_list list, each element is a n_k-by-1 response vector.
#' @param knockoffs method used to construct knockoffs for the X variables. By defaut, create.fixed is used.
#' also see \code{\link[knockoff]{knockoff.filter}} in knockoff package.
#' @param statistic used to assess variable importance. By default,
#' a lasso statistic with coefficent difference is used.
#' also see \code{\link[knockoff]{knockoff.filter}} in knockoff package
#' @param fdr target false discovery rate (default: 0.2).
#'
#' @return An object of class "Gknockoff.result". This object is a list
#'  containing at least the following components:
#'  \item{statistic}{computed test statistics}
#'  \item{threshold}{computed selection threshold}
#'  \item{selected}{named vector of selected variables}
#'
#' @details
#' This function apply FDR control to integration analysis from multiple data source by Generalized Lasso.
#' The parameters \code{X_list} and \code{y_list} contants the data matrix and response
#' from K multiple data source.
#'
#' @export
GKnockoff_integration <- function(X_list, y_list,
                                    knockoffs = create.fixed,
                                    statistic = stat.lasso_coefdiff,
                                    fdr = 0.2){
  if(!(is.list(X_list)&is.list(y_list))){
    stop('Inputs are not list')
  }
  if(length(X_list) != length(y_list)){
    stop('X_list and y_list are not the same length')
  }

  if (!is.function(knockoffs)) stop('Input knockoffs must be a function')
  if (!is.function(statistic)) stop('Input statistic must be a function')

  p <- dim(X_list[[1]])[2]
  X <- X_list[[1]]
  k <- length(X_list)

  for(i in 2:k){
    current_X <- X_list[[i]]
    if(dim(current_X)[2] != p) {stop('elements in X_list are not the same column numbers')}
    X <- magic::adiag(X, current_X)
  }

  y <- NULL
  for(i in 1:k){
    current_y <- matrix(y_list[[i]], ncol = 1)
    y <- rbind(y, current_y)
  }

  n_all <- dim(X)[1]
  D <- create.gdmatrix(k, p)
  aug <- matrix(data = 0, nrow = p, ncol = k*p)
  aug[, ((k-1)*p + 1) : (k*p)] <- diag(p)
  D_tilde <- rbind(D, aug)
  D_tilde_inverse <- solve(D_tilde)

  Z <- D_tilde_inverse[,1:((k-1)*p)]

  F1 <- D_tilde_inverse[,((k-1)*p + 1) : (k*p)]

  XF <- X %*% F1
  M_XF <- diag(n_all) - XF %*% solve(t(XF) %*% XF) %*% t(XF)
  y_bar <- M_XF %*% y
  X_bar <- M_XF %*% X %*% Z

  fit <- knockoff.filter(X_bar, y_bar, knockoffs = create.fixed, statistic = stat.lasso_coefdiff, fdr = fdr, offset = 1)

  structure(list(call = match.call(),
                 statistic = fit$W,
                 threshold = fit$t,
                 selected = fit$selected),
            class = 'Gknockoff.result')
}
