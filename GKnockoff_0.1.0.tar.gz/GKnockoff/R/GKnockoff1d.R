#' FDR control for 1-dimensional piecewise constant coefficients profile via GKnockoff
#'
#' This function runs the GKnockoff procedure from start to finish for 1-dimensional time series piecewise constant
#' coefficients profile.
#'
#' @param y response vector of length n-by-1 matrix.
#' @param knockoffs method used to construct knockoffs for the X variables. By defaut, create.fixed is used.
#' also see \code{\link[knockoff]{knockoff.filter}} in knockoff package
#' @param statistic used to assess variable importance. By default,
#' a lasso statistic with coefficent difference is used.
#' also see \code{\link[knockoff]{knockoff.filter}} in knockoff package
#' @param fdr target false discovery rate (default: 0.2).
#'
#' @return An object of class "Gknockoff.result". This object is a list
#'  containing at least the following components:
#'  \item{statistic}{computed test statistics}
#'  \item{threshold}{computed selection threshold}
#'  \item{selected}{named vector of selected variables}
#'
#' @details
#' This function apply a FDR control procedure for change-points detection via GKnockoff
#'
#' @export
GKnockoff1d <- function(y,
                          knockoffs = create.fixed,
                          statistic = stat.lasso_coefdiff,
                          fdr = 0.2){
  if(!is.matrix(y)){
    stop('y is not a matrix')
  }
  if (!is.function(knockoffs)) stop('Input knockoffs must be a function')
  if (!is.function(statistic)) stop('Input statistic must be a function')
  p <- dim(y)[1]
  X <- diag(p)
  D <- create.dmatrix(p)

  D_tilde <- rbind(D, rep(1, p))
  D_tilde_inverse <- solve(D_tilde)

  Z <- D_tilde_inverse[,1:(p-1)]
  F1 <- D_tilde_inverse[,p]
  XF <- X %*% F1

  M_XF <- diag(p) - XF %*% solve(t(XF) %*% XF) %*% t(XF)

  y_bar <- M_XF %*% y

  X_bar <- M_XF %*% X %*% Z

  fit <- knockoff.filter(X_bar, y_bar, knockoffs = knockoffs,
                                   statistic = statistic, fdr = fdr, offset = 1)

  structure(list(call = match.call(),
                 statistic = fit$W,
                 threshold = fit$t,
                 selected = fit$selected),
            class = 'Gknockoff.result')
}
