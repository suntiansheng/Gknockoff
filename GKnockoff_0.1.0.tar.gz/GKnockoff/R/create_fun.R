# Augment D to tilde_D
Augment_D <- function(D){
  m <- dim(D)[1]
  p <- dim(D)[2]
  I_m <- diag(p)
  i <- 1
  while(TRUE){
    current_m <- rbind(D, I_m[,i])
    if(qr(current_m)$rank > m) {
      break()
    }else{
        i <- i + 1
      }
  }

  if(qr(current_m)$rank == p){
    return(current_m)
  }else{
    return(Augment_D(current_m))
    }
}


#' Create extended penalty matrix
#'
#' This function augment D to a invertible matrix by adding some extra row-matrix to its bottom
#' if D is a feasible penalty matrix.
#'
#' @param D m-by-p penalty matrix.
#' @return extended penalty matrix that is invertible.
#'
#' @details
#' Augment penalty m-by-p matrix D to a p-by-p invertible matrix if D is a feasible penalty matrix.
#' The definition of feaible penalty matrix is that the matrix can be extended to a invertible matrix
#' by adding some extra row-matrix to its bottom.
#' when m > p, the matrix is infeasible.
#' when m <= p, and rank of matrix is m, then matrix is feasible.
#'
#' @examples
#' D <- matrix(c(1,0,0, 0,1,0), nrow = 2, ncol = 3, byrow = TRUE)
#' create.tilde_D(D)
#'
#' @export
create.tilde_D <- function(D){
  D <- as.matrix(D)
  m <- dim(D)[1]
  p <- dim(D)[2]
  # case one
  if(m > p){
    stop('m > p, the penalty matrix is infeasible')
  }
  #case two
  if(m == p){
    if(rank(qr(D)$rank == m)){
      tilde_D <- D
    }else{
      stop('m = p, but rank(D) < m, the penalty matrix is infeasible')
    }
  }

  if(m < p){
    if(qr(D)$rank == m){
      tilde_D <- Augment_D(D)
    }else{
      stop('m < p, but rank(D) < m, the penalty matrix is infeasible')
    }
  }
  return(tilde_D)
}

#' Create difference penalty matrix
#'
#' @param p the dimension of difference penalty matrix
#'
#' @return A p-by-(p-1) different penalty matrix with each row (..., -1, 1, ...)
#'
#' @export
create.dmatrix <- function(p){
  E <- matrix(0, nrow = p-1, ncol = p)
  for(i in 1:(p-1)){
    E[i,i] <- -1
    E[i, i+1] <- 1
  }
  return(E)
}

#' Create generalized difference penalty matrix
#'
#' @param k the number of data source
#' @param p the number of variables in data set
#'
#' @return A (kp)-by-(k(p-1)) different penalty matrix with each row (..., -I, I, ...), where I is
#' a p-by-p identity matrix
#'
#' @export
create.gdmatrix <- function(k, p){

  D <- matrix(data = 0, nrow = (k-1)*p, ncol = k*p)

  start <- 1
  end <- p
  for(i in 1:(k-1)){
    D[start:end, start:end] <- diag(p)
    D[start:end, (start+p) : (end+p)] <- -diag(p)

    start <- start + p
    end <- end + p
  }

  return(D)
}
